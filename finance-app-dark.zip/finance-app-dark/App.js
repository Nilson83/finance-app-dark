
import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, SafeAreaView, StatusBar, StyleSheet } from 'react-native';

export default function App() {
  const [theme, setTheme] = useState('executivo');

  const themes = {
    executivo: {
      bg: '#121212',
      card: '#1e1e1e',
      text: '#f1f1f1',
      secondary: '#a1a1a1',
      green: '#22c55e',
      red: '#ef4444'
    },
    cyber: {
      bg: '#0f0f1a',
      card: '#1a1a2e',
      text: '#f8f8f2',
      secondary: '#00f7ff',
      green: '#2ecc71',
      red: '#ff4d6d'
    }
  };

  const current = themes[theme];

  const transactions = [
    { date: '15/04/2025', desc: 'Salário', value: '+ R$ 5.000,00', type: 'in' },
    { date: '14/04/2025', desc: 'Aluguel', value: '- R$ 1.200,00', type: 'out' },
    { date: '13/04/2025', desc: 'Freelance', value: '+ R$ 2.200,00', type: 'in' },
  ];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: current.bg, paddingTop: 40 }}>
      <StatusBar barStyle="light-content" backgroundColor={current.bg} />
      <View style={{ padding: 16 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 }}>
          <Text style={{ color: current.text, fontSize: 24, fontWeight: 'bold' }}>FinanceApp</Text>
          <TouchableOpacity onPress={() => setTheme(theme === 'executivo' ? 'cyber' : 'executivo')} style={styles.button}>
            <Text style={{ color: '#fff' }}>Tema: {theme === 'executivo' ? 'Cyber' : 'Executivo'}</Text>
          </TouchableOpacity>
        </View>

        <View style={[styles.card, { backgroundColor: current.card }]}>
          <Text style={{ color: current.secondary }}>Saldo</Text>
          <Text style={{ color: current.green, fontSize: 20, fontWeight: 'bold' }}>R$ 7.200,00</Text>
        </View>
        <View style={[styles.card, { backgroundColor: current.card }]}>
          <Text style={{ color: current.secondary }}>Entradas</Text>
          <Text style={{ color: current.green, fontSize: 20, fontWeight: 'bold' }}>R$ 10.000,00</Text>
        </View>
        <View style={[styles.card, { backgroundColor: current.card }]}>
          <Text style={{ color: current.secondary }}>Saídas</Text>
          <Text style={{ color: current.red, fontSize: 20, fontWeight: 'bold' }}>R$ 2.800,00</Text>
        </View>

        <View style={[styles.card, { backgroundColor: current.card, marginTop: 20 }]}>
          <Text style={{ color: current.text, fontWeight: '600', marginBottom: 8 }}>Últimas transações</Text>
          <FlatList
            data={transactions}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => (
              <View style={styles.row}>
                <Text style={[styles.cell, { color: current.text }]}>{item.date}</Text>
                <Text style={[styles.cell, { color: current.text }]}>{item.desc}</Text>
                <Text style={[styles.cell, { color: item.type === 'in' ? current.green : current.red }]}>{item.value}</Text>
              </View>
            )}
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 12
  },
  button: {
    backgroundColor: '#333',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: '#444'
  },
  cell: {
    fontSize: 14,
    width: '30%'
  }
});
